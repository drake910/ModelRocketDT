# -*- coding: utf-8 -*-
"""
Created 4/23/2019
2D Model Rocket Simulation A8-3 Engine
"""

import scipy.integrate as si
import numpy as np
import matplotlib.pylab as plt


# Thrust force 
def T(t):
    Tm = 6.75
    tm = 0.2
    Tb = 2.1
    tb = 0.4
    tf = 0.6
    if t<tm:
        T = (Tm/tm)*t
    elif t<tb:
        s = (Tb-Tm)/(tb-tm)
        T = (s*t)+(Tm-s*tm)
    elif t<tf:
        T = Tb
    else:
        T = 0
        
    return T


def calc_RHS(y,t,p):
#   y = a list that contains the system state
#   t = the time for which the right-hand-side of the system equations
#       is to be calculated
#   p = a tuple that contains any parameters needed for the model
  
#   Unpack the state of the system
    y0 = y[0]
    y1 = y[1]
    y2 = y[2]
    y3 = y[3]

#   Unpack the parameterlist
    m, Cd, theta_0 = p
    g = 9.81
    L = 0.75
    A = 0.0009577
    rho = 1.225
    Lx = L*np.sin(theta_0)
    Ly = L*np.cos(theta_0)

#   Define v
    v = np.sqrt(y1**2 + y3**2)
    
#   Drag Force
    D = 0.5*(rho)*Cd*A*(v**2)

#   Calculate the derivatives
    if y0<Ly and y2<Lx:
        dy0dt = y1
        dy1dt = (T(t)*np.cos(theta_0) - D*np.cos(theta_0))/m - \
        g*np.cos(theta_0)*np.cos(theta_0)
        dy2dt = y3
        dy3dt = (T(t)*np.sin(theta_0) - D*np.sin(theta_0))/m - \
        g*np.cos(theta_0)*np.sin(theta_0)
    else:
        cos_theta = np.abs(y1)/v
        sin_theta = np.abs(y3)/v
        dy0dt = y1
        dy1dt = (T(t)*cos_theta - D*cos_theta*np.sign(y1))/m - g
        dy2dt = y3
        dy3dt = (T(t)*sin_theta - D*sin_theta)/m 
    return [dy0dt,dy1dt,dy2dt,dy3dt]

#--Main Program 

#   Define the initial conditions
y0 = [0.0,0,0,0]

#   Define the time grid
t = np.linspace(0,8,200)
    
#   Define model parameters
m = 0.0856 # kg
g = 9.81 # m/s^2
rho = 1.225 # kg/m^3
Cd = 0.75 #
A = 0.0009577 # m^2
theta_0 = 0.55 # radians
L = 0.75 # m

p =  m, Cd, theta_0
    
#   Solve the DE
sol = si.odeint(calc_RHS,y0,t,args=(p,))
y0 = sol[:,0]
y1 = sol[:,1]
y2 = sol[:,2]
y3 = sol[:,3]

#   Plot the theory
fig = plt.figure()

xd = fig.add_subplot(1,2,1)
xd.plot(t,y2,linestyle='-')
xd.set_xlabel('$t \\ [s]$')
xd.set_ylabel('$x \\ [m]$')
xd.set_title('Model Rocket Launch A8-3 Engine x dvt')
plt.grid()

yd = fig.add_subplot(1,2,2)
yd.plot(t,y0,linestyle='-')
yd.set_ylim(0,15)
yd.set_xlabel('$t \\ [s]$')
yd.set_ylabel('$y \\ [m]$')
yd.set_title('Model Rocket Launch A8-3 Engine y dvt')
plt.grid()

plt.tight_layout()
plt.subplots_adjust(wspace=3)
plt.show()


